est.prob <-
function (cor.obs = NULL, cor.null = NULL, pplot = FALSE, bw = 0.3,
    zlim = 1, ...){
    # Empirical Bayes calculation (posterior and p0)
    # Using kernel density on the distribution
    # Author: Yudi Pawitan (yudi.pawitan@ki.se),
    #         modified by Arief Gusnanto (A.Gusnanto@leeds.ac.uk)
    den0 = density(cor.null)
    den = density(cor.obs, bw = bw)
    z = seq(-zlim, zlim, len = 300)
    f0 = approx(den0$x, den0$y, xout = z, rule = 2)$y
    f = approx(den$x, den$y, xout = z, rule = 2)$y
    ff0 = f/f0
    p0 = min(f[abs(z) < 0.4]/f0[abs(z) < 0.4])
    p1 = 1 - p0
    p1z = 1 - p0/ff0
    f1 = p1z * f/p1
    prob = approx(z, p1z, xout = cor.obs, rule = 2)$y
    prob = ifelse(prob < 0, 0, prob)
    if (pplot) {
        plot(cor.obs, prob, xlab="Correlation", ylab="Probability", xlim=c(-1,1), ...)
    }
    invisible(return(list(prob = prob, p0 = p0, p1 = p1, cor.obs = cor.obs)))
}
