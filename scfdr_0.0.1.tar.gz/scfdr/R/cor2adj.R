cor2adj <-
function(x, sparse=TRUE, threshold=NULL){
# This functuion will create adjacency matrix from
# correlation matrix.
# x can be sparse or non-sparse matrix
# if x is sparse, non-zero will be set to one
# and zero will be kept at zero
# if x is non-sparse, correlation
# above the threshold will be set to 1
# and zero otherwise.
# Regardless, correlation of a variable to itself
# will be set to zero in the adj matrix.
# a.gusnanto@leeds.ac.uk
if(!sparse & is.null(threshold)) stop("threshold cannot be null for non-sparse correlation matrix.")
if(!sparse){
if(threshold >= 1 | threshold <= -1) stop("threshold cannot exceed one in absolute value.")
 }
if(any(x > 1 | x < -1)) stop("correlation cannot exceed one in absolute value.")
if(nrow(x) != ncol(x)) stop("correlation matrix must be a square matrix.")
y <- x
if(sparse){
   y[y!=0] <- 1
 } else {
   y[abs(y)>threshold] <- 1
   y[abs(y)<=threshold] <- 0
 }# end if else
diag(y) <- 0
return(y)
}
