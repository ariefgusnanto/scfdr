corrs <-
function(data, method="pearson", ...){
# (Wrapper) Function to calculate correlations.
# 'data' must be matrix or data frame, with
# no missing values, and no non-numeric values.
# 'method' options are: pearson, kendall, spearman,
# rmad, and xicor (must be exact)
# The first three will call cor()
# rmad and xicor are calling the
# RSC and XICOR package, respectively
# A.Gusnanto@leeds.ac.uk
if(all(method != c("pearson", "kendall", "spearman", "rmad"))) stop("Argument `method' must be either `pearson', `kendall', `spearman', or `rmad'")

if(method %in% c("pearson", "kendall", "spearman")){
   res <- cor(data, method=method, ...)
  }# End of if(method %in% c("pearson", "kendall", "spearman")

if(method == "rmad"){
   require(RSC)
   res <- as.matrix(rmad(data, ...))
  }# End of if(method == "rmad")

return(res)
}
