vec2mat <-
function(x){
  a <- 1:100000
  if(all(a*(a-1)!=2*length(x))) stop("length of x is not correct.")
  p <- which(a*(a-1)==2*length(x))
  r <- matrix(NA, nrow=p, ncol=p)
  r[upper.tri(r)] <- x
  r <- t(r)
  r[upper.tri(r)] <- x
  diag(r) <- 1
  return(r)
}
