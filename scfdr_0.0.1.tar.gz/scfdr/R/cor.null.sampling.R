cor.null.sampling <-
function(dat, method="pearson", sampling=1, niter=10, mc.cores=8){
require(parallel)
counter <- as.list(1:niter)
if(sampling <= 0 | sampling > 1) stop("Argument `sampling' must be between 0 and 1.")
pselect <- ceiling(sampling*ncol(dat))
if(pselect <=1) stop("No or only one variable is selected. Try to increase `sampling'.")

  fff <- function(x, dat, method, pselect){
   select <- sort(sample(1:ncol(dat), pselect))
   x.star <- apply(dat[,select],2,sample) 
   r.star <- corrs(data=x.star, method=method)
   return(c(r.star[upper.tri(r.star)]))
   } # End of fff

res <- mclapply(counter, fff, dat=dat, method=method, pselect=pselect, mc.cores=mc.cores)
return(res)
}
