mat2vec <-
function(x)  return(c(x[upper.tri(x)]))
