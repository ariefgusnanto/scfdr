thresh.cor <-
function(res, FDR=0.05, cut=NULL){
# Function to perform threshold the correlations based on the 
# false discovery rate (FDR)
# Input: output of est.prob
# or a list with components cor.obs and prob
# A.Gusnanto@leeds.ac.uk

if(is.null(res$prob) | is.null(res$cor.obs)) stop("res should be a list with components cor.obs and prob.")
prob <- res$prob
fdr <- 1-prob
cor.obs <- res$cor.obs
p <- length(prob)
if(any(prob<0 | prob>1)) stop("prob should be between zero and one.")
if(any(cor.obs < -1 | cor.obs > 1)) stop("cor.obs should be between -1 and 1.")

if(is.null(cut)){
order.abs.cor <- order(abs(cor.obs), decreasing=T)
sorted.abs.cor <- abs(cor.obs)[order.abs.cor]
#max.select <- max(which(cumsum(fdr[order.abs.cor])<=FDR))
max.select <- max(which(cumsum(fdr[order.abs.cor])/seq_along(fdr[order.abs.cor])<=FDR))
cor.cut <- sorted.abs.cor[max.select]
cor.res <- cor.obs
cor.res[abs(cor.res)<cor.cut] <- 0
attr(cor.res,"observed") <- cor.obs
attr(cor.res,"fdr") <- fdr
attr(cor.res,"threshold") <- cor.cut
return(cor.res)
} else {
cor.res <- cor.obs
cor.res[fdr>=cut] <- 0
attr(cor.res,"observed") <- cor.obs
attr(cor.res,"fdr") <- fdr
attr(cor.res,"fdr.cut") <- cut
return(cor.res)
} # End of if else
}
